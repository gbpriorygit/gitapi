<title>Formation</title>
<div class="content" style="margin-top: 30px;">
    <div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
              <div class="card">
                  <div class="card-header" data-background-color="blue">
                      <h4 class="title">
                              Formation
                      </h4>
                  </div>
                  <div class="card-content">
                      <div class="row" id="docs">
                          <div class="card-content table-responsive">
                              <table class="table table-hover">
                                <tr><td><a href="https://any1coin.com/web-trader">Web Trader</a></td></tr>
                                <tr><td><a href="https://any1coin.com/tradetechlimitedgroup4setup.exe">MT4 Download</a></td></tr>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
