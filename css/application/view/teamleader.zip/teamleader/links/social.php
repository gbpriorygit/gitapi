<title>Social Media</title>
<div class="content" style="margin-top: 30px;">
    <div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
              <div class="card">
                  <div class="card-header" data-background-color="blue">
                      <h4 class="title">
                              Social Media
                      </h4>
                  </div>
                  <div class="card-content">
                      <div class="row" id="docs">
                          <div class="card-content table-responsive">
                              <table class="table table-hover">
                                <tr><td><a target="_blank" class="fuse_social_icons_links" href="https://www.facebook.com/Any1coincom-1078093015710493/">	<i class="fa fa-facebook fb-awesome-social awesome-social"></i>&nbsp;&nbsp;Facebook</a></td></tr>
                                <tr><td><a target="_blank" class="fuse_social_icons_links" href="https://twitter.com/Any1Coin">	<i class="fa fa-twitter tw-awesome-social awesome-social"></i>&nbsp;&nbsp;Twitter</a></td></tr>
                                <tr><td><a target="_blank" class="fuse_social_icons_links" href="https://www.linkedin.com/company/any1coin">	<i class="fa fa-linkedin linkedin-awesome-social awesome-social"></i>&nbsp;&nbsp;LinkedIn</a></td></tr>
                                <tr><td><a target="_blank" class="fuse_social_icons_links" href="https://www.youtube.com/channel/UCCish7yYg2-wsMBxjUUWbyQ">	<i class="fa fa-youtube youtube-awesome-social awesome-social"></i>&nbsp;&nbsp;YouTube</a></td></tr>
                                <tr><td><a target="_blank" class="fuse_social_icons_links" href="https://www.instagram.com/any1coin.official/">	<i class="fa fa-instagram instagram-awesome-social awesome-social"></i>&nbsp;&nbsp;Instagram</a></td></tr>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
