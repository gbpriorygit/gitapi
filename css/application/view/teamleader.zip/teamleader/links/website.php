<title>Website</title>
<div class="content" style="margin-top: 30px;">
    <div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
              <div class="card">
                  <div class="card-header" data-background-color="blue">
                      <h4 class="title">
                              Website
                      </h4>
                  </div>
                  <div class="card-content">
                      <div class="row" id="docs">
                          <div class="card-content table-responsive">
                              <table class="table table-hover">
                                <tr><td><a target='_blank' href="https://any1coin.com/">https://any1coin.com/</a></td></tr>
                                <tr><td><a target='_blank' href="https://economyguardian.com/">https://economyguardian.com/</a></td></tr>
                                <tr><td><a target='_blank' href="https://accademiaditrading.com/">https://accademiaditrading.com/</a></td></tr>
                                <tr><td><a target='_blank' href="https://any1coin.io/">https://any1coin.io/</a></td></tr>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
