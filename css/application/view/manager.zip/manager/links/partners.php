<title>Partners</title>
<div class="content" style="margin-top: 30px;">
    <div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
              <div class="card">
                  <div class="card-header" data-background-color="blue">
                      <h4 class="title">
                              Partners
                      </h4>
                  </div>
                  <div class="card-content">
                      <div class="row" id="docs">
                          <div class="card-content table-responsive">
                              <table class="table table-hover">
<tr><td><pre>
DEUTSCHE HANDELSBANK
IBAN:   DE22700111104101058013
SWIFT:  DEKTDE7GXXX
Beneficiary:  TFU
Bank:  Deutsche Handelsbank (Deutsche Kontor Privatbank)
Bank Address:  Elsenheimerstrasse 41, 80687 Munich, Germany

Website:<a target="_blank" href="https://www.handelsbank.com">https://www.handelsbank.com/</a></pre> </td></tr>

<tr><td><pre>
MISTERTANGO
IBAN:   LT113510000021393995
SWIFT:  MIEGLT21
Beneficiary:  TradeTech Group
Bank:  Mistertango
Bank Address:  Vilnius 12126 Lithuania

Website:<a target="_blank" href="https://www.mistertango.com">https://www.mistertango.com</a></pre></td></tr>
                              </table>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
</div>
